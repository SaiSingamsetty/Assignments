﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ImageSlicing
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label3.Text = "Please select a url of .jpg image.\n If not mentioned, default url will be used.";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(ValidateChildren(ValidationConstraints.Enabled))
            {
                label4.Visible = true;
                label4.Text = "Images folder have detailed analysis.\nPlease check";
                //textBox1.Text != string.Empty && textBox2.Text != string.Empty
                // Retrieving user entered value and assigning no of splits to two variables which helps me cutting into pieces
                int actualvalue = Convert.ToInt32(textBox1.Text);
                List<int> xvalues = new List<int>();
                for (int start = 1; start < actualvalue; start++)
                {
                    if (actualvalue % start == 0)
                    {
                        xvalues.Add(start);
                    }
                }

                Random rnd = new Random();
                int xval = rnd.Next(xvalues.Count);

                int x = Convert.ToInt32(xvalues[xval]);
                int y = Convert.ToInt32(actualvalue / x);

                int Counter = 1; // variable for split images names. Ex: Part1, Part2..

                string startpath = Directory.GetParent(Environment.CurrentDirectory).Parent.FullName;

                DownloadImage(Convert.ToString(textBox2.Text));

                Image img = Image.FromFile(@"../../Images/Downloaded.jpg");

                int eachWidth = (int)((double)img.Width / x);
                int eachHeight = (int)((double)img.Height / y);
                Bitmap[,] bmps = new Bitmap[x, y];

                //Slicing images into x*y parts and saving bitmap records.
                for (int i = 0; i < x; i++)
                    for (int j = 0; j < y; j++)
                    {
                        bmps[i, j] = new Bitmap(eachWidth, eachHeight);
                        Graphics g = Graphics.FromImage(bmps[i, j]);
                        g.DrawImage(img, new Rectangle(0, 0, eachWidth, eachHeight), new Rectangle(i * eachWidth, j * eachHeight, eachWidth, eachHeight), GraphicsUnit.Pixel);

                        g.Dispose();

                        bmps[i, j].Save(@"../../Images/Part" + Counter + ".jpg", ImageFormat.Jpeg);
                        Counter++;
                    }

                string finalImage = @"../../Images/FinalImage.jpg"; //variable to specify the final destination folder
                int picid = 1; // temporary variable to collect Partitioned images from saved location
                Bitmap[] tempbits = new Bitmap[x];
                for (int i = 1; i <= x; i++)
                {
                    List<string> verticalimagelist = new List<string>();
                    for (int j = 1; j <= y; j++)
                    {
                        verticalimagelist.Add("\\Images\\Part" + picid + ".jpg");
                        picid++;
                    }
                    tempbits[i - 1] = CombineImagesVertical(verticalimagelist);
                    
                }

                Bitmap combbitmap = new Bitmap(img.Width, img.Height);
                Graphics combgraphics = Graphics.FromImage(combbitmap);
                int position = 0;
                foreach (Bitmap bm in tempbits)
                {
                    combgraphics.DrawImage(bm, new Point(position, 0));
                    position += bm.Width;
                }

                combbitmap.Save(finalImage, ImageFormat.Jpeg);
                
                for (int k= 0; k < tempbits.Length; k++)
                {
                    tempbits[k].Dispose();
                }
                
                combbitmap.Dispose();
                combgraphics.Dispose();

                


            }
            else
            {
                MessageBox.Show("Please complete both fields to process");
            }

        }

        private Bitmap CombineImagesVertical(List<string> files)
        {
            
            //string finalImage = @"D:\\tempImages.jpg";
            List<int> imageWidths = new List<int>();
            int tempIndex = 0;
            int height = 0;
            string startpath = Directory.GetParent(Environment.CurrentDirectory).Parent.FullName;

            // Collecting heights and widths
            foreach (string file in files)
            {
                string temppath = startpath+file;
                Image img = Image.FromFile(temppath);
                imageWidths.Add(img.Width); // Adding all widths to a list. 
                height += img.Height; // Total height to make a bitmap
                img.Dispose();
            }

            int width = imageWidths.Max(); //Anyways they wil be same
            Bitmap verticalImage = new Bitmap(width, height);
            Graphics g = Graphics.FromImage(verticalImage);

            g.Clear(SystemColors.AppWorkspace);

            foreach (string file in files)
            {
                string temppath = startpath + file;
                Image img = Image.FromFile(temppath);
                if (tempIndex == 0)
                {
                    g.DrawImage(img, new Point(0, 0));
                    tempIndex++;
                    height = img.Height;
                }
                else
                {
                    g.DrawImage(img, new Point(0, height));
                    height += img.Height;
                }
                img.Dispose();
            }
            g.Dispose();
            //img3.Save(finalImage, ImageFormat.Jpeg);
            
            return verticalImage;
        }


        private void DownloadImage(string path)
        {
            using (WebClient client = new WebClient())
            {
                if (path == string.Empty) path = "http://personal.psu.edu/xqz5228/jpg.jpg";
                var expression = @"/[-a - zA - Z0 - 9@:% _\+.~#?&//=]{2,256}\.[a-z]{2,4}\b(\/[-a-zA-Z0-9@:%_\+.~#?&//=]*)?/gi";
                Regex regex = new Regex(expression);
                path = regex.IsMatch(path) ? path : "http://personal.psu.edu/xqz5228/jpg.jpg";
                client.DownloadFile(new Uri(path), @"../../Images/Downloaded.jpg");
            }

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            label3.Visible = true;
            
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            
        }

        private void textBox1_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                e.Cancel = true;
                textBox1.Focus();
                errorProvider1.SetError(textBox1,"!");
            }
        }

        private void textBox2_Enter(object sender, EventArgs e)
        {

        }
    }
}
